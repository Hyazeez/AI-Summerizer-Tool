import img1 from "../assets/img1.png";
import img2 from "../assets/img2.png";

export const assets = {
    img1,
    img2
};

export default assets;