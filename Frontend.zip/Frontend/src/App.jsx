import React, { useState } from "react";
import axios from "axios";
import assets from "./assets/assets";
import "./App.css";

const App = () => {
  const [text, setText] = useState("");
  const [summary, setSummary] = useState("");
  const [error, setError] = useState("");
  const [file, setFile] = useState(null);
  const [youtubeURL, setYoutubeURL] = useState("");
  const [mode, setMode] = useState("text");
  const [loading, setLoading] = useState(false);

  const API_URL = "http://localhost:5000";

  const handleSummarize = async () => {
    setLoading(true);
    setSummary("");
    setError("");

    try {
      let res;
      if (mode === "text") {
        if (!text.trim()) return alert("Please enter some text");
        res = await axios.post(`${API_URL}/summarize/text`, { text });
      } else if (mode === "pdf") {
        if (!file) return alert("Please upload a PDF file");
        const formData = new FormData();
        formData.append("file", file);
        res = await axios.post(`${API_URL}/summarize/pdf`, formData, {
          headers: { "Content-Type": "multipart/form-data" },
        });
      } else if (mode === "youtube") {
        if (!youtubeURL.trim()) return alert("Please enter a YouTube URL");
        res = await axios.post(`${API_URL}/summarize/youtube`, {
          url: youtubeURL,
        });
      }

      // Handle backend response
      if (res.data.success) {
        setSummary(res.data.summary);
      } else {
        setError(res.data.error || "Failed to generate summary.");
      }
    } catch (err) {
      console.error(err);
      setError("Server error. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="App">
      <h1>
        <img
          className="image-info"
          src={assets.img1}
          alt="AI Summarizer"
          width={60}
          height={60}
        />
        AI Summarizer (Text, PDF, YouTube)
      </h1>

      <div className="mode-buttons">
        <button
          className={mode === "text" ? "active" : ""}
          onClick={() => setMode("text")}
        >
          Text
        </button>
        <button
          className={mode === "pdf" ? "active" : ""}
          onClick={() => setMode("pdf")}
        >
          PDF
        </button>
        <button
          className={mode === "youtube" ? "active" : ""}
          onClick={() => setMode("youtube")}
        >
          YouTube
        </button>
      </div>

      {mode === "text" && (
        <textarea
          placeholder="Paste your text here..."
          rows="10"
          value={text}
          onChange={(e) => setText(e.target.value)}
        ></textarea>
      )}

      {mode === "pdf" && (
        <input
          type="file"
          accept="application/pdf"
          onChange={(e) => setFile(e.target.files[0])}
        />
      )}

      {mode === "youtube" && (
        <input
          type="text"
          placeholder="Paste your YouTube URL..."
          value={youtubeURL}
          onChange={(e) => setYoutubeURL(e.target.value)}
        />
      )}

      <button
        className="button-info"
        onClick={handleSummarize}
        disabled={loading}
      >
        {loading ? "Summarizing..." : "Summarize"}
      </button>

      {/* Error Box */}
      {error && (
        <div className="error-box">
          <strong>Error:</strong> {error}
        </div>
      )}

      {/* Summary Box */}
      {summary && (
        <div className="summary">
          <h2>
            <img
              className="image-info"
              src={assets.img2}
              alt="Summarization"
              width={40}
              height={40}
            />
            Summary
          </h2>
          <p>{summary}</p>
          <button
            onClick={() => navigator.clipboard.writeText(summary)}
            className="copy-btn"
          >
            Copy Summary
          </button>
        </div>
      )}
    </div>
  );
};

export default App;
